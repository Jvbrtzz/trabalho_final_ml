"""Camada HTTP da API."""

