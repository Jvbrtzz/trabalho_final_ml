"""Entrega da interface web."""

