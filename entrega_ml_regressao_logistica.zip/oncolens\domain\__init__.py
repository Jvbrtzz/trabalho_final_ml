"""Entidades do domínio."""

